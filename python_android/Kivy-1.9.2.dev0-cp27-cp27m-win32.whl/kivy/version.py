# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.9.2.dev0'
__hash__ = '3e1ea7392a2aae77d3ca9ec60787d118d3ba0164'
__date__ = '20170315'
